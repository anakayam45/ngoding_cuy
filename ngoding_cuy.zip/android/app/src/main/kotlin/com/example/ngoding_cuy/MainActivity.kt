package com.example.ngoding_cuy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
